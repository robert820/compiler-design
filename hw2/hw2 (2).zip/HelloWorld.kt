/* Hello World Example */
class HelloWorld {

  fun add (a: int, b: int) : int {
    return a+b
  }
	 fun main () {
    //c = add(a, 10)
    if (c > 10)
      print -c
    else
      print c
    println ("Hello World")
	  }
}
